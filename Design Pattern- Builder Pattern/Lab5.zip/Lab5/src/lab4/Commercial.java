package lab4;

public interface Commercial {
	
	public void setCommercial(String title);

}
